public abstract class FileHandler implements Writable {

    public void save(Object object){

    }

    public Object read(){
        return null;
    }

//    @Override
//    public void save() {
//        System.out.println("Сохранили");
//    }
//
//    @Override
//    public Object read() {
//        return null;
//    }
}
